import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyA8T4TLHkr59CBh7RxgU9FHb_EXpnFVaKU",
  authDomain: "react-crud-bd1b9.firebaseapp.com",
  projectId: "react-crud-bd1b9",
  storageBucket: "react-crud-bd1b9.appspot.com",
  messagingSenderId: "943455851500",
  appId: "1:943455851500:web:b63fb61a3cf8854a2ba6c9",
  measurementId: "G-S43G9RJ6T0",
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
